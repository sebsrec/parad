#ifndef selectArena
#define selectArena

#include <string>

std::string getRandomArenaType();

#endif
